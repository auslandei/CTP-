# vn.xspeed

大连飞创XSpeed期货柜台的接口。

API版本：XSpeedAPI_V1.0.9.14_sp3

由于飞创API的原生头文件中的代码排版格式较差（空格不规范、代码缩进不规范），在pyscript脚本生成封装代码的过程中有大量函数出错，需要手动修改。
