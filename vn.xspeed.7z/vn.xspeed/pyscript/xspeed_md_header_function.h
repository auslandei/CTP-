int reqUserLogin(dict req);

int reqUserLogout(dict req);

int reqTradingDay(dict req);

